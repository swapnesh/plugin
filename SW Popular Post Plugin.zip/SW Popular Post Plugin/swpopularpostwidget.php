<?php
/*
Plugin Name: Sw Popular Post Widget
Plugin URI: http://demo.test.com
Author: Swapnesh Kumar Sinha
Description: Go your Widget Section to check the widget. It is a general purpose plugin that creates a widget to limit the popular post display from 1 to 10 at front end of your site. Please leave your honest comments,suggestions, bugs etc regarding the plugin at my email id - "swapnesh20032003@gmail.com". The plugin is in working condition, tested at - WordPress 3.5.
########
INSTALL it via plugin section in your Wordpress Admin panel and then find it under APPEARANCE -> WIDGETS section.
######## 
Version: 1.0
Author URI: http://swapneshsinha.wordpress.com
*/

class SwPopularPostWidget extends WP_Widget {

public function __construct() {
	//Widget actual processes
	$widget_options = array( 'Description' => 'Show Popular Posts' );
	parent::__construct( 'SwPopularPostWidget', 'Sw Popular Post Widget', $widget_options); 
}

public function form( $instance ) {
	//outputs the options form on admin
$instance = wp_parse_args( (array) $instance, array( 'popularpostcount' => '','popularpostheading' => '' ) );
$popularpostcount = $instance['popularpostcount'];
$popularpostheading = $instance['popularpostheading'];
echo "Heading Title";	
echo "<input type='text' name='".$this->get_field_name('popularpostheading')."' id='".$this->get_field_name('popularpostheading')."' value='".$popularpostheading."' />";
echo "Number of post to show ";	
//echo "<select name='popularpostcount' id='popularpostcount'>";
echo "<select name='".$this->get_field_name('popularpostcount')."' id='".$this->get_field_name('popularpostcount')."'>";
	for( $i =1; $i<=10; $i++ )
	{
		if ( $i == $popularpostcount )
		echo "<option value='".$i."' selected>".$i."</option>";
		else
		echo "<option value='".$i."'>".$i."</option>";
	} 
echo "</select>";
}

public function update( $new_instance, $old_instance ) {
	//processes widget options to be saved
	$instance = $old_instance;
    $instance['popularpostcount'] = $new_instance['popularpostcount'];
    $instance['popularpostheading'] = $new_instance['popularpostheading'];
    return $instance;
}

public function widget( $args ,  $instance ) {
	//outputs the content of widget
	extract($args);
	$popularpostcount = apply_filters('widget_title', $instance['popularpostcount']);
	$popularpostheading = apply_filters('widget_title', $instance['popularpostheading']);
	echo '<aside class="widget widget_meta" id="popular-2">';
	echo  '<h3 class="widget-title">'.$popularpostheading.'</h3>';
    echo  "<ul>";
    echo $this->popularPosts($popularpostcount);
    echo  "</ul>";
}


public function popularPosts($num)
{
	 global $wpdb;
    
    $posts = $wpdb->get_results("SELECT comment_count, ID, post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , $num");
	
    foreach ($posts as $post) {
        setup_postdata($post);
        $id = $post->ID;
        $title = $post->post_title;
        $count = $post->comment_count;
        
        if ($count != 0) {
            $popular .= '<li>';
            $popular .= '<a href="' . get_permalink($id) . '" title="">' . $title.'</a> '." - ".$count." Comments";
            $popular .= '</li>';
        }
    }
    return $popular;
}


}

add_action( 'widgets_init' , create_function('', 'register_widget( "swpopularpostwidget" );' ) );