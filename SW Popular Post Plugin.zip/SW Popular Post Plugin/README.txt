This plugin is a part of my educational counter with Wordpress plugin development. It is a general purpose plugin that creates a widget under widget section. It limits the post display from 1 to 10 at front end of your site.

Please leave your honest comments,suggestions, bugs etc regarding the plugin at my email id - "swapnesh20032003@gmail.com".

The plugin is in working condition, tested at - WordPress 3.5.

########
Install it via plugin section in your Wordpress Admin panel.
######## 